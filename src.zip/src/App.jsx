import { useState } from "react";
import EmployeeForm from "./components/EmployeeForm";
import EmployeeList from "./components/EmployeeList";
import CardPreview from "./components/CardPreview";
import { useLocalStorage } from "./hooks/useLocalStorage";
import { EMPTY_EMPLOYEE, SAMPLE_EMPLOYEE } from "./config";
import { validateEmployee } from "./utils/validate";
import { nextEmployeeId } from "./utils/format";

export default function App() {
  const [employees, setEmployees] = useLocalStorage("id-cards:employees", []);
  const [draft, setDraft] = useState(SAMPLE_EMPLOYEE);
  const [errors, setErrors] = useState({});
  const [notice, setNotice] = useState("");

  const isEditing = employees.some((e) => e.employeeId === draft.employeeId);

  function handleSubmit() {
    const found = validateEmployee(draft);
    setErrors(found);
    if (Object.keys(found).length) {
      setNotice("");
      return;
    }
    setEmployees((prev) =>
      isEditing
        ? prev.map((e) => (e.employeeId === draft.employeeId ? draft : e))
        : [...prev, draft]
    );
    setNotice(isEditing ? "Employee updated." : "Employee saved.");
  }

  function handleSelect(emp) {
    setDraft(emp);
    setErrors({});
    setNotice("");
  }

  function handleDelete(id) {
    setEmployees((prev) => prev.filter((e) => e.employeeId !== id));
    if (draft.employeeId === id) setDraft(EMPTY_EMPLOYEE);
  }

  return (
    <div className="app">
      <header className="app-header no-print">
        <h1>ID card studio</h1>
        <p>Create, preview and print employee ID cards. Changes show on the card as you type.</p>
      </header>

      <main className="layout">
        <div className="left no-print">
          <EmployeeForm
            values={draft}
            errors={errors}
            isEditing={isEditing}
            onChange={setDraft}
            onSubmit={handleSubmit}
            onReset={() => {
              setDraft(EMPTY_EMPLOYEE);
              setErrors({});
              setNotice("");
            }}
            onSuggestId={() =>
              setDraft({ ...draft, employeeId: nextEmployeeId(employees) })
            }
          />
          {notice && <p className="notice" role="status">{notice}</p>}
          <EmployeeList
            employees={employees}
            activeId={draft.employeeId}
            onSelect={handleSelect}
            onDelete={handleDelete}
          />
        </div>

        <CardPreview employee={draft} />
      </main>
    </div>
  );
}
