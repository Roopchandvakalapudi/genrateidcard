import { useRef, useState } from "react";
import { CardFront, CardBack } from "./IdCard";
import { downloadNode } from "../utils/download";

export default function CardPreview({ employee }) {
  const frontRef = useRef(null);
  const backRef = useRef(null);
  const [status, setStatus] = useState("");

  const slug = (employee.employeeId || "id-card").toLowerCase();

  async function save(ref, side) {
    try {
      setStatus("Preparing image…");
      await downloadNode(ref.current, `${slug}-${side}.png`);
      setStatus(`Saved ${side} of the card as PNG.`);
    } catch {
      setStatus("Could not create the image. Try again.");
    }
  }

  return (
    <section className="preview">
      <div className="preview-actions no-print">
        <button className="btn" onClick={() => save(frontRef, "front")}>
          Download front
        </button>
        <button className="btn" onClick={() => save(backRef, "back")}>
          Download back
        </button>
        <button className="btn btn-primary" onClick={() => window.print()}>
          Print both sides
        </button>
        <p className="status" role="status">{status}</p>
      </div>

      <div className="cards">
        <CardFront ref={frontRef} employee={employee} />
        <CardBack ref={backRef} employee={employee} />
      </div>
    </section>
  );
}
