import { useRef, useState } from "react";
import { BLOOD_GROUPS, DEPARTMENTS } from "../config";
import { processPhoto } from "../utils/image";

function Field({ label, error, children }) {
  return (
    <label className="field">
      <span className="field-label">{label}</span>
      {children}
      {error && (
        <span className="field-error" role="alert">
          {error}
        </span>
      )}
    </label>
  );
}

export default function EmployeeForm({
  values,
  errors,
  isEditing,
  onChange,
  onSubmit,
  onReset,
  onSuggestId,
}) {
  const fileRef = useRef(null);
  const [photoError, setPhotoError] = useState("");

  const set = (name) => (e) => onChange({ ...values, [name]: e.target.value });

  async function handlePhoto(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      setPhotoError("");
      onChange({ ...values, photo: await processPhoto(file) });
    } catch (err) {
      setPhotoError(err.message);
    }
  }

  return (
    <form
      className="panel form"
      onSubmit={(e) => {
        e.preventDefault();
        onSubmit();
      }}
      noValidate
    >
      <h2>{isEditing ? "Edit employee" : "New employee"}</h2>

      <div className="photo-row">
        <div className="photo-thumb">
          {values.photo ? <img src={values.photo} alt="" /> : <span>No photo</span>}
        </div>
        <div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            onChange={handlePhoto}
            hidden
          />
          <button type="button" className="btn" onClick={() => fileRef.current.click()}>
            {values.photo ? "Change photo" : "Upload photo"}
          </button>
          {values.photo && (
            <button
              type="button"
              className="btn btn-quiet"
              onClick={() => onChange({ ...values, photo: "" })}
            >
              Remove
            </button>
          )}
          <p className="hint">Portrait works best. It is cropped to 4:5 automatically.</p>
          {photoError && <p className="field-error" role="alert">{photoError}</p>}
        </div>
      </div>

      <div className="grid">
        <Field label="Full name" error={errors.fullName}>
          <input value={values.fullName} onChange={set("fullName")} autoComplete="off" />
        </Field>

        <Field label="Employee ID" error={errors.employeeId}>
          <div className="input-action">
            <input
              value={values.employeeId}
              onChange={(e) =>
                onChange({ ...values, employeeId: e.target.value.toUpperCase() })
              }
              placeholder="NWL-1024"
            />
            <button type="button" className="btn btn-quiet" onClick={onSuggestId}>
              Suggest
            </button>
          </div>
        </Field>

        <Field label="Designation" error={errors.designation}>
          <input value={values.designation} onChange={set("designation")} />
        </Field>

        <Field label="Department">
          <select value={values.department} onChange={set("department")}>
            {Object.keys(DEPARTMENTS).map((d) => (
              <option key={d}>{d}</option>
            ))}
          </select>
        </Field>

        <Field label="Joining date" error={errors.joinDate}>
          <input type="date" value={values.joinDate} onChange={set("joinDate")} />
        </Field>

        <Field label="Blood group (optional)">
          <select value={values.bloodGroup} onChange={set("bloodGroup")}>
            <option value="">Not shown on card</option>
            {BLOOD_GROUPS.map((b) => (
              <option key={b}>{b}</option>
            ))}
          </select>
        </Field>

        <Field label="Mobile number" error={errors.phone}>
          <input
            inputMode="numeric"
            value={values.phone}
            onChange={set("phone")}
            placeholder="98765 43210"
          />
        </Field>

        <Field label="Work email" error={errors.email}>
          <input type="email" value={values.email} onChange={set("email")} />
        </Field>

        <Field label="Office location">
          <input value={values.location} onChange={set("location")} />
        </Field>
      </div>

      <div className="actions">
        <button type="submit" className="btn btn-primary">
          {isEditing ? "Update employee" : "Save employee"}
        </button>
        <button type="button" className="btn btn-quiet" onClick={onReset}>
          Clear form
        </button>
      </div>
    </form>
  );
}
