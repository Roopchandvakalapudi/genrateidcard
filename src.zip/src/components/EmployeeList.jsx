import { DEPARTMENTS } from "../config";
import { initials } from "../utils/format";

export default function EmployeeList({ employees, activeId, onSelect, onDelete }) {
  return (
    <section className="panel">
      <h2>Saved employees</h2>
      {employees.length === 0 ? (
        <p className="empty">
          No employees saved yet. Fill in the form and choose Save employee to add the first one.
        </p>
      ) : (
        <ul className="list">
          {employees.map((emp) => (
            <li key={emp.employeeId} className={emp.employeeId === activeId ? "active" : ""}>
              <button className="list-main" onClick={() => onSelect(emp)}>
                <span
                  className="avatar"
                  style={{ background: DEPARTMENTS[emp.department]?.color }}
                >
                  {emp.photo ? <img src={emp.photo} alt="" /> : initials(emp.fullName)}
                </span>
                <span>
                  <strong>{emp.fullName}</strong>
                  <small>
                    {emp.employeeId} · {emp.designation}
                  </small>
                </span>
              </button>
              <button
                className="btn btn-quiet"
                onClick={() => onDelete(emp.employeeId)}
                aria-label={`Delete ${emp.fullName}`}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
