import { forwardRef } from "react";
import { QRCodeSVG } from "qrcode.react";
import { COMPANY, DEPARTMENTS } from "../config";
import { formatDate, formatPhone, initials } from "../utils/format";

const accentFor = (department) => DEPARTMENTS[department]?.color ?? "#0E7C86";

export const CardFront = forwardRef(function CardFront({ employee }, ref) {
  const { fullName, designation, department, employeeId, bloodGroup, photo } = employee;
  return (
    <article
      ref={ref}
      className="card"
      style={{ "--accent": accentFor(department) }}
      aria-label={`ID card front for ${fullName || "employee"}`}
    >
      <header className="card-top">
        <span className="lanyard-slot" />
        <div className="brand">
          <span className="brand-mark">{COMPANY.mark}</span>
          <span className="brand-name">{COMPANY.name}</span>
        </div>
      </header>

      <div className="photo">
        {photo ? (
          <img src={photo} alt={`Portrait of ${fullName}`} />
        ) : (
          <span className="photo-initials">{initials(fullName) || "?"}</span>
        )}
      </div>

      <div className="card-body">
        <h2 className="card-name">{fullName || "Full name"}</h2>
        <p className="card-role">{designation || "Designation"}</p>
        <p className="card-dept">{department}</p>
      </div>

      <footer className="card-bottom">
        <span className="card-id">{employeeId || "NWL-0000"}</span>
        {bloodGroup && <span className="blood">{bloodGroup}</span>}
      </footer>
    </article>
  );
});

export const CardBack = forwardRef(function CardBack({ employee }, ref) {
  const { employeeId, department, email, phone, joinDate, location, bloodGroup } = employee;
  const rows = [
    ["Email", email || "—"],
    ["Mobile", formatPhone(phone)],
    ["Joined", formatDate(joinDate)],
    ["Location", location || "—"],
    ...(bloodGroup ? [["Blood group", bloodGroup]] : []),
  ];
  return (
    <article
      ref={ref}
      className="card card-back"
      style={{ "--accent": accentFor(department) }}
      aria-label="ID card back"
    >
      <header className="back-top">
        <span className="lanyard-slot" />
        <p>Property of {COMPANY.name}</p>
      </header>

      <div className="qr-wrap">
        <QRCodeSVG
          value={`${COMPANY.verifyUrl}${employeeId || "NWL-0000"}`}
          size={128}
          level="M"
          marginSize={0}
        />
        <p>Scan to verify this card</p>
      </div>

      <dl className="details">
        {rows.map(([label, value]) => (
          <div key={label}>
            <dt>{label}</dt>
            <dd>{value}</dd>
          </div>
        ))}
      </dl>

      <footer className="back-foot">
        <p>If found, please return to</p>
        <p>{COMPANY.address}</p>
        <p>{COMPANY.helpline}</p>
      </footer>
    </article>
  );
});
