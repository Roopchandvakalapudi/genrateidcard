// Change these to brand the cards for any company.
export const COMPANY = {
  name: "Northwind Labs",
  mark: "N",
  address: "4th Floor, Tech Park, Visakhapatnam, Andhra Pradesh 530045",
  helpline: "+91 891 200 0000",
  // The QR code on the back points here. Employee ID is appended.
  verifyUrl: "https://example.com/verify/",
};

export const DEPARTMENTS = {
  Engineering: { color: "#0E7C86" },
  Design: { color: "#A63D7A" },
  Marketing: { color: "#C46A1A" },
  "Human Resources": { color: "#4A6FA5" },
  Finance: { color: "#3B7A4B" },
  Operations: { color: "#7A5A3C" },
};

export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];

export const EMPTY_EMPLOYEE = {
  fullName: "",
  employeeId: "",
  designation: "",
  department: "Engineering",
  joinDate: "",
  bloodGroup: "",
  phone: "",
  email: "",
  location: "Visakhapatnam",
  photo: "",
};

export const SAMPLE_EMPLOYEE = {
  fullName: "Ananya Reddy",
  employeeId: "NWL-1024",
  designation: "Senior Frontend Engineer",
  department: "Engineering",
  joinDate: "2022-08-01",
  bloodGroup: "B+",
  phone: "9876543210",
  email: "ananya.reddy@northwind.dev",
  location: "Visakhapatnam",
  photo: "",
};
