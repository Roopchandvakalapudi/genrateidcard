import { toPng } from "html-to-image";

export async function downloadNode(node, filename) {
  const dataUrl = await toPng(node, { pixelRatio: 3, cacheBust: true });
  const link = document.createElement("a");
  link.download = filename;
  link.href = dataUrl;
  link.click();
}
