export function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return "—";
  // en-IN gives day-first dates, e.g. 01 Aug 2022
  return d.toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}

export function formatPhone(digits) {
  const d = String(digits || "").replace(/\D/g, "").slice(-10);
  if (d.length !== 10) return digits || "—";
  return `+91 ${d.slice(0, 5)} ${d.slice(5)}`;
}

export function initials(name) {
  return (name || "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join("");
}

export function nextEmployeeId(existing) {
  const nums = existing
    .map((e) => parseInt(String(e.employeeId).split("-")[1], 10))
    .filter((n) => !Number.isNaN(n));
  const next = nums.length ? Math.max(...nums) + 1 : 1001;
  return `NWL-${next}`;
}
