// Center-crops to a 4:5 portrait and shrinks the photo so it stays small
// enough to keep in localStorage.
export function processPhoto(file, width = 320) {
  return new Promise((resolve, reject) => {
    if (!file.type.startsWith("image/")) {
      reject(new Error("Choose an image file (JPG or PNG)."));
      return;
    }
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.onload = () => {
      const img = new Image();
      img.onerror = () => reject(new Error("Could not open that image."));
      img.onload = () => {
        const height = Math.round(width * 1.25);
        const targetRatio = width / height;
        let sw = img.width;
        let sh = img.height;
        if (sw / sh > targetRatio) sw = sh * targetRatio;
        else sh = sw / targetRatio;
        const sx = (img.width - sw) / 2;
        const sy = (img.height - sh) / 2;
        const canvas = document.createElement("canvas");
        canvas.width = width;
        canvas.height = height;
        canvas.getContext("2d").drawImage(img, sx, sy, sw, sh, 0, 0, width, height);
        resolve(canvas.toDataURL("image/jpeg", 0.85));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}
