export function validateEmployee(e) {
  const errors = {};
  if (e.fullName.trim().length < 3) errors.fullName = "Enter the employee's full name.";
  if (!/^[A-Z]{2,4}-\d{3,6}$/.test(e.employeeId.trim()))
    errors.employeeId = "Use a format like NWL-1024.";
  if (!e.designation.trim()) errors.designation = "Enter a designation.";
  if (!e.joinDate) errors.joinDate = "Pick a joining date.";
  if (!/^[6-9]\d{9}$/.test(e.phone.replace(/\s/g, "")))
    errors.phone = "Enter a 10-digit Indian mobile number.";
  if (!/^\S+@\S+\.\S+$/.test(e.email)) errors.email = "Enter a valid email address.";
  return errors;
}
